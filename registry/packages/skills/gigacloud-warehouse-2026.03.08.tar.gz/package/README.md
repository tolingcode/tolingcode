# 大健云仓 Skill (GigaCloud Warehouse)

**跨境电商 B2B 分销平台操作技能**

大健云仓是跨境电商 B2B 分销平台，卖家可以获取平台产品，通过 AI 工具修改产品信息和图片，发布到自己的电商平台，有订单后推送给大健云仓发货。

---

## 功能特性

| 功能 | 说明 |
|------|------|
| 产品搜索 | 搜索大健云仓平台产品 |
| 产品详情 | 获取产品详细信息（含图片） |
| 图片下载 | 批量下载产品图片 |
| 库存查询 | 实时查询产品库存 |
| 订单推送 | 创建订单并推送给大健云仓 |
| 物流跟踪 | 获取订单物流信息 |
| AI 优化 | AI 优化产品信息和图片 |
| 完整工作流 | 一键完成获取→处理→发布流程 |

---

## 安装

```bash
# 使用 tolingcode 安装
tolingcode install skills gigacloud-warehouse

# 或手动安装
npm install -g gigacloud-warehouse
```

---

## 配置

在 OpenClaw 配置文件中添加：

```json
{
  "skills": {
    "gigacloud-warehouse": {
      "domain": "https://api.gigacloudlogistics.com",
      "clientId": "your_client_id",
      "clientSecret": "your_client_secret",
      "token": "your_auth_token",
      "outputDir": "./output/images"
    }
  }
}
```

---

## 使用示例

### 初始化

```javascript
const gigacloud = require('gigacloud-warehouse');

gigacloud.init({
  clientId: 'api_dropship_test',
  clientSecret: 'test12345',
  token: 'your_auth_token'
});
```

### 获取产品详情

```javascript
// 单个产品
const product = await gigacloud.getProductDetail('W508P23025');

// 多个产品
const products = await gigacloud.getProductDetail(['W508P23025', 'W508S00002']);
```

### 搜索产品

```javascript
const results = await gigacloud.searchProducts('办公椅', 1, 20);
```

### 下载产品图片

```javascript
const images = await gigacloud.downloadProductImages('W508P23025');
console.log(images); 
// [{ url, filepath, filename }, ...]
```

### 查询库存

```javascript
const stock = await gigacloud.getStockInfo(['W508P23025', 'W508S00002']);
```

### 创建订单（推送发货）

```javascript
const order = await gigacloud.createOrder({
  orderNo: 'ORD20260308001',
  items: [
    {
      sku: 'W508P23025',
      quantity: 2
    }
  ],
  shippingAddress: {
    name: 'John Doe',
    address: '123 Main St',
    city: 'Los Angeles',
    state: 'CA',
    zip: '90001',
    country: 'US',
    phone: '+1-555-0100'
  }
});
```

### 查询订单状态

```javascript
const status = await gigacloud.getOrderStatus('ORD20260308001');
```

### 物流跟踪

```javascript
const tracking = await gigacloud.getTrackingInfo('ORD20260308001');
```

### AI 优化产品信息

```javascript
// 为 Amazon 平台优化
const optimized = await gigacloud.optimizeProductInfo('W508P23025', 'amazon');
console.log(optimized.suggestions);
// { title, keywords, category, price }
```

### 创建 AI 处理任务

```javascript
const task = await gigacloud.createAITask('W508P23025', {
  removeBackground: true,
  watermark: 'My Store',
  resize: { width: 1000, height: 1000 },
  translate: 'en'
});
```

### 完整工作流

```javascript
const result = await gigacloud.workflow('W508P23025', {
  downloadImages: true,
  optimize: true,
  targetPlatform: 'amazon',
  aiModifications: {
    removeBackground: true,
    translate: 'en'
  }
});

console.log(result.steps); 
// 显示每个步骤的执行状态
```

---

## API 参考

### 核心 API

| 方法 | 参数 | 返回 | 说明 |
|------|------|------|------|
| `init(config)` | 配置对象 | 初始化结果 | 初始化技能 |
| `getProductDetail(skus)` | SKU 字符串或数组 | 产品详情 | 获取产品信息 |
| `searchProducts(keyword, page, pageSize)` | 关键词，页码，每页数量 | 搜索结果 | 搜索产品 |
| `getProductImages(sku)` | SKU | 图片列表 | 获取产品图片 |
| `downloadProductImages(sku)` | SKU | 下载结果 | 下载图片到本地 |
| `getStockInfo(skus)` | SKU 数组 | 库存信息 | 查询库存 |
| `createOrder(orderData)` | 订单数据 | 订单结果 | 创建订单 |
| `getOrderStatus(orderNo)` | 订单号 | 订单状态 | 查询订单 |
| `getTrackingInfo(orderNo)` | 订单号 | 物流信息 | 物流跟踪 |
| `optimizeProductInfo(sku, platform)` | SKU, 平台名 | 优化建议 | AI 优化 |
| `createAITask(sku, modifications)` | SKU, 修改选项 | 任务信息 | 创建 AI 任务 |
| `workflow(sku, options)` | SKU, 选项 | 完整结果 | 完整工作流 |

---

## 工作流程图

```
┌─────────────┐
│  搜索产品   │
└──────┬──────┘
       ↓
┌─────────────┐
│  获取详情   │
│  (含图片)   │
└──────┬──────┘
       ↓
┌─────────────┐
│  下载图片   │
└────────────┘
       ↓
┌─────────────┐
│  AI 优化    │
│  标题/描述  │
│  图片处理   │
└────────────┘
       ↓
┌─────────────┐
│  发布到     │
│  电商平台   │
└──────┬──────┘
       ↓
┌─────────────┐
│  有订单     │
└────────────┘
       ↓
┌─────────────┐
│  推送给     │
│  大健云仓   │
└──────┬──────┘
       ↓
┌─────────────┐
│  云仓发货   │
│  物流跟踪   │
└─────────────┘
```

---

## 支持的平台

**电商平台**:
- Amazon
- eBay
- Shopify
- Etsy
- Wish
- TikTok Shop

**图片处理**:
- 背景移除
- 水印添加
- 尺寸调整
- 格式转换
- AI 增强

**AI 优化**:
- 标题优化
- 关键词提取
- 分类建议
- 价格建议
- 多语言翻译

---

## 错误处理

```javascript
try {
  const product = await gigacloud.getProductDetail('INVALID_SKU');
} catch (error) {
  console.error('错误:', error.message);
  // 常见错误:
  // - 请先初始化技能
  // - 获取产品详情失败：无效的 SKU
  // - 认证失败：请检查 clientId 和 clientSecret
}
```

---

## 相关文件

```
gigacloud-warehouse/
├── index.js          # 主入口
├── lib/
│   ├── api.js        # API 客户端
│   └── image.js      # 图片处理
├── package.json
└── README.md
```

---

## 相关链接

- **大健云仓**: https://www.gigacloudlogistics.com
- **API 文档**: https://api.gigacloudlogistics.com/docs
- **GitHub**: https://github.com/tolingcode/tolingcode
- **问题反馈**: GitHub Issues

---

**作者**: 韩宝军 (TolingCode)  
**License**: MIT  
**版本**: 2026.03.08
