/**
 * 大健云仓 Skill 使用示例
 * GigaCloud Warehouse Usage Examples
 */

const gigacloud = require('../index');

// ============================================
// 1. 初始化配置
// ============================================
gigacloud.init({
  domain: 'https://api.gigacloudlogistics.com',
  clientId: 'api_dropship_test',
  clientSecret: 'test12345',
  token: 'your_auth_token_here',
  outputDir: './output/images'
});

// ============================================
// 2. 搜索产品
// ============================================
async function exampleSearch() {
  console.log('=== 搜索产品 ===');
  const results = await gigacloud.searchProducts('办公椅', 1, 10);
  console.log('找到产品:', results.data?.length || 0);
  results.data?.forEach(p => {
    console.log(`- ${p.sku}: ${p.title}`);
  });
}

// ============================================
// 3. 获取产品详情
// ============================================
async function exampleGetProduct() {
  console.log('\n=== 获取产品详情 ===');
  const product = await gigacloud.getProductDetail('W508P23025');
  console.log('产品:', product.data?.title);
  console.log('价格:', product.data?.price);
  console.log('图片数量:', product.data?.images?.length || 0);
}

// ============================================
// 4. 下载产品图片
// ============================================
async function exampleDownloadImages() {
  console.log('\n=== 下载产品图片 ===');
  const images = await gigacloud.downloadProductImages('W508P23025');
  console.log('下载完成:');
  images.forEach(img => {
    if (img.filepath) {
      console.log(`✓ ${img.filename}`);
    } else {
      console.log(`✗ ${img.filename}: ${img.error}`);
    }
  });
}

// ============================================
// 5. 查询库存
// ============================================
async function exampleGetStock() {
  console.log('\n=== 查询库存 ===');
  const stock = await gigacloud.getStockInfo(['W508P23025', 'W508S00002']);
  console.log('库存信息:', stock.data);
}

// ============================================
// 6. 创建订单（推送发货）
// ============================================
async function exampleCreateOrder() {
  console.log('\n=== 创建订单 ===');
  const order = await gigacloud.createOrder({
    orderNo: 'ORD20260308001',
    items: [
      { sku: 'W508P23025', quantity: 2 }
    ],
    shippingAddress: {
      name: 'John Doe',
      address: '123 Main St',
      city: 'Los Angeles',
      state: 'CA',
      zip: '90001',
      country: 'US',
      phone: '+1-555-0100',
      email: 'john@example.com'
    }
  });
  console.log('订单创建:', order.data?.orderNo);
}

// ============================================
// 7. 查询订单状态
// ============================================
async function exampleOrderStatus() {
  console.log('\n=== 订单状态 ===');
  const status = await gigacloud.getOrderStatus('ORD20260308001');
  console.log('订单状态:', status.data?.status);
  console.log('物流单号:', status.data?.trackingNo);
}

// ============================================
// 8. 物流跟踪
// ============================================
async function exampleTracking() {
  console.log('\n=== 物流跟踪 ===');
  const tracking = await gigacloud.getTrackingInfo('ORD20260308001');
  console.log('物流信息:', tracking.data);
}

// ============================================
// 9. AI 优化产品信息
// ============================================
async function exampleOptimize() {
  console.log('\n=== AI 优化产品 ===');
  const optimized = await gigacloud.optimizeProductInfo('W508P23025', 'amazon');
  console.log('优化建议:');
  console.log('- 标题:', optimized.suggestions?.title);
  console.log('- 关键词:', optimized.suggestions?.keywords);
  console.log('- 分类:', optimized.suggestions?.category);
  console.log('- 建议价格:', optimized.suggestions?.price);
}

// ============================================
// 10. 创建 AI 处理任务
// ============================================
async function exampleAITask() {
  console.log('\n=== 创建 AI 任务 ===');
  const task = await gigacloud.createAITask('W508P23025', {
    removeBackground: true,
    watermark: 'My Store',
    resize: { width: 1000, height: 1000 },
    translate: 'en',
    title: 'Ergonomic Office Chair with Lumbar Support'
  });
  console.log('AI 任务创建:');
  console.log('- 任务 ID:', task.taskId);
  console.log('- 文件路径:', task.filepath);
}

// ============================================
// 11. 完整工作流
// ============================================
async function exampleWorkflow() {
  console.log('\n=== 完整工作流 ===');
  const result = await gigacloud.workflow('W508P23025', {
    downloadImages: true,
    optimize: true,
    targetPlatform: 'amazon',
    aiModifications: {
      removeBackground: true,
      translate: 'en'
    }
  });
  
  console.log('工作流执行结果:');
  result.steps.forEach(step => {
    const icon = step.status === 'success' ? '✓' : step.status === 'failed' ? '✗' : '○';
    console.log(`${icon} Step ${step.step}: ${step.name} - ${step.status}`);
  });
  
  if (result.optimized) {
    console.log('\n优化后的信息:');
    console.log('- 建议标题:', result.optimized.suggestions.title);
    console.log('- 建议价格:', result.optimized.suggestions.price);
  }
  
  if (result.images) {
    console.log('\n下载的图片:');
    result.images.forEach(img => {
      if (img.filepath) console.log(`✓ ${img.filename}`);
    });
  }
}

// ============================================
// 运行示例
// ============================================
async function runExamples() {
  try {
    // 选择要运行的示例
    await exampleSearch();
    await exampleGetProduct();
    // await exampleDownloadImages();
    // await exampleGetStock();
    // await exampleCreateOrder();
    // await exampleOrderStatus();
    // await exampleTracking();
    // await exampleOptimize();
    // await exampleAITask();
    // await exampleWorkflow();
    
    console.log('\n✅ 示例执行完成');
  } catch (error) {
    console.error('❌ 错误:', error.message);
  }
}

// 如果直接运行此文件
if (require.main === module) {
  runExamples();
}

module.exports = { runExamples };
