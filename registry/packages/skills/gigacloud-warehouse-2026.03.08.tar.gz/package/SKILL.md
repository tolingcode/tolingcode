# 大健云仓 Skill (gigacloud-warehouse)

## 技能说明

大健云仓是跨境电商 B2B 分销平台操作技能，支持：

1. **产品管理** - 搜索、获取产品详情和图片
2. **库存查询** - 实时查询产品库存状态
3. **订单处理** - 创建订单并推送给大健云仓发货
4. **物流跟踪** - 获取订单物流信息
5. **AI 优化** - AI 优化产品信息和图片处理

## 使用场景

跨境电商卖家典型工作流程：

```
1. 搜索大健云仓产品 → 找到合适的商品
2. 获取产品详情和图片 → 了解产品信息
3. AI 优化产品信息 → 适配目标平台
4. 发布到自己店铺 → Amazon/eBay/Shopify 等
5. 客户下单 → 自动/手动推送订单
6. 大健云仓发货 → 跟踪物流状态
```

## 配置方法

在 OpenClaw 配置中添加：

```json
{
  "skills": {
    "gigacloud-warehouse": {
      "clientId": "your_client_id",
      "clientSecret": "your_client_secret",
      "token": "your_auth_token",
      "domain": "https://api.gigacloudlogistics.com"
    }
  }
}
```

## 快速开始

### 安装

```bash
tolingcode install skills gigacloud-warehouse
```

### 初始化

```javascript
const gigacloud = require('gigacloud-warehouse');
gigacloud.init({
  clientId: 'api_dropship_test',
  clientSecret: 'test12345'
});
```

### 基本使用

```javascript
// 搜索产品
const products = await gigacloud.searchProducts('办公椅');

// 获取详情
const product = await gigacloud.getProductDetail('W508P23025');

// 下载图片
await gigacloud.downloadProductImages('W508P23025');

// AI 优化
const optimized = await gigacloud.optimizeProductInfo('W508P23025', 'amazon');

// 创建订单
await gigacloud.createOrder({
  orderNo: 'ORD001',
  items: [{ sku: 'W508P23025', quantity: 2 }],
  shippingAddress: { /* ... */ }
});
```

## API 参考

详细文档见 [README.md](./README.md)

## 文件结构

```
gigacloud-warehouse/
├── index.js              # 主入口
├── lib/
│   ├── api.js            # API 客户端
│   └── image.js          # 图片处理
├── examples/
│   └── usage.js          # 使用示例
├── openclaw.skill.js     # OpenClaw 集成
├── skill.json            # 技能配置
├── package.json
├── README.md
└── SKILL.md              # 本文件
```

## 依赖

- axios: HTTP 请求
- crypto: 签名加密

## 注意事项

1. **API 凭证** - 需要大健云仓 API 账号
2. **网络** - 需要能访问 api.gigacloudlogistics.com
3. **图片存储** - 确保 output 目录有写入权限
4. **订单推送** - 确保订单格式符合大健云仓要求

## 相关资源

- 大健云仓官网：https://www.gigacloudlogistics.com
- API 文档：https://api.gigacloudlogistics.com/docs
- GitHub: https://github.com/tolingcode/tolingcode

## 版本

2026.03.08
