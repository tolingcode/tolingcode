/**
 * 大健云仓 Skill - OpenClaw Agent 集成
 * 用于 OpenClaw AI Agent 调用
 */

const gigacloud = require('./index');

module.exports = {
  name: 'gigacloud-warehouse',
  displayName: '大健云仓',
  version: '2026.03.08',
  description: '跨境电商 B2B 分销平台 - 产品获取、图片处理、订单推送',
  
  /**
   * 技能初始化
   */
  async init(context) {
    const config = context.config?.gigacloud || {};
    if (!config.clientId || !config.clientSecret) {
      return {
        success: false,
        message: '请配置大健云仓 API 凭证 (clientId, clientSecret)'
      };
    }
    
    gigacloud.init(config);
    return {
      success: true,
      message: '大健云仓技能已激活'
    };
  },
  
  /**
   * 可用的工具/命令
   */
  tools: {
    /**
     * 搜索产品
     */
    'search': {
      description: '搜索大健云仓平台产品',
      params: {
        keyword: { type: 'string', required: true, description: '搜索关键词' },
        page: { type: 'number', default: 1, description: '页码' },
        pageSize: { type: 'number', default: 20, description: '每页数量' }
      },
      async execute({ keyword, page, pageSize }) {
        const results = await gigacloud.searchProducts(keyword, page, pageSize);
        return {
          success: true,
          data: results.data || [],
          total: results.total || 0,
          page,
          pageSize
        };
      }
    },
    
    /**
     * 获取产品详情
     */
    'get-product': {
      description: '获取产品详细信息（含图片）',
      params: {
        skus: { type: 'array', required: true, description: '产品 SKU 列表' }
      },
      async execute({ skus }) {
        const product = await gigacloud.getProductDetail(skus);
        return {
          success: true,
          data: product.data
        };
      }
    },
    
    /**
     * 获取产品图片
     */
    'get-images': {
      description: '获取产品图片列表',
      params: {
        sku: { type: 'string', required: true, description: '产品 SKU' }
      },
      async execute({ sku }) {
        const images = await gigacloud.getProductImages(sku);
        return {
          success: true,
          data: images
        };
      }
    },
    
    /**
     * 下载产品图片
     */
    'download-images': {
      description: '下载产品图片到本地',
      params: {
        sku: { type: 'string', required: true, description: '产品 SKU' }
      },
      async execute({ sku }) {
        const images = await gigacloud.downloadProductImages(sku);
        return {
          success: true,
          data: images,
          message: `已下载 ${images.length} 张图片`
        };
      }
    },
    
    /**
     * 查询库存
     */
    'get-stock': {
      description: '查询产品库存信息',
      params: {
        skus: { type: 'array', required: true, description: '产品 SKU 列表' }
      },
      async execute({ skus }) {
        const stock = await gigacloud.getStockInfo(skus);
        return {
          success: true,
          data: stock.data
        };
      }
    },
    
    /**
     * 创建订单
     */
    'create-order': {
      description: '创建订单并推送给大健云仓发货',
      params: {
        orderNo: { type: 'string', required: true, description: '订单号' },
        items: { 
          type: 'array', 
          required: true, 
          description: '订单商品列表 [{sku, quantity}]' 
        },
        shippingAddress: {
          type: 'object',
          required: true,
          description: '收货地址'
        }
      },
      async execute({ orderNo, items, shippingAddress }) {
        const order = await gigacloud.createOrder({
          orderNo,
          items,
          shippingAddress
        });
        return {
          success: true,
          data: order.data,
          message: '订单已创建并推送给大健云仓'
        };
      }
    },
    
    /**
     * 查询订单状态
     */
    'get-order-status': {
      description: '查询订单状态',
      params: {
        orderNo: { type: 'string', required: true, description: '订单号' }
      },
      async execute({ orderNo }) {
        const status = await gigacloud.getOrderStatus(orderNo);
        return {
          success: true,
          data: status.data
        };
      }
    },
    
    /**
     * 物流跟踪
     */
    'get-tracking': {
      description: '获取物流跟踪信息',
      params: {
        orderNo: { type: 'string', required: true, description: '订单号' }
      },
      async execute({ orderNo }) {
        const tracking = await gigacloud.getTrackingInfo(orderNo);
        return {
          success: true,
          data: tracking.data
        };
      }
    },
    
    /**
     * AI 优化产品
     */
    'optimize-product': {
      description: 'AI 优化产品信息（标题、关键词、价格等）',
      params: {
        sku: { type: 'string', required: true, description: '产品 SKU' },
        platform: { 
          type: 'string', 
          required: true, 
          description: '目标平台 (amazon/ebay/shopify/etsy)',
          enum: ['amazon', 'ebay', 'shopify', 'etsy', 'wish', 'tiktok']
        }
      },
      async execute({ sku, platform }) {
        const optimized = await gigacloud.optimizeProductInfo(sku, platform);
        return {
          success: true,
          data: optimized,
          message: `已为 ${platform} 平台优化产品信息`
        };
      }
    },
    
    /**
     * 完整工作流
     */
    'workflow': {
      description: '完整工作流：获取→下载→优化→准备发布',
      params: {
        sku: { type: 'string', required: true, description: '产品 SKU' },
        options: {
          type: 'object',
          default: {},
          description: '选项配置'
        }
      },
      async execute({ sku, options }) {
        const result = await gigacloud.workflow(sku, options);
        return {
          success: true,
          data: result,
          message: '工作流执行完成'
        };
      }
    }
  },
  
  /**
   * 快捷命令（自然语言）
   */
  commands: [
    {
      pattern: /搜索大健云仓产品 (.+)/i,
      tool: 'search',
      map: (match) => ({ keyword: match[1] })
    },
    {
      pattern: /获取产品 (.+) 的详情/i,
      tool: 'get-product',
      map: (match) => ({ skus: [match[1]] })
    },
    {
      pattern: /下载 (.+) 的图片/i,
      tool: 'download-images',
      map: (match) => ({ sku: match[1] })
    },
    {
      pattern: /查询 (.+) 的库存/i,
      tool: 'get-stock',
      map: (match) => ({ skus: [match[1]] })
    },
    {
      pattern: /创建订单 (.+)/i,
      tool: 'create-order',
      map: (match) => JSON.parse(match[1])
    },
    {
      pattern: /查询订单 (.+) 的状态/i,
      tool: 'get-order-status',
      map: (match) => ({ orderNo: match[1] })
    },
    {
      pattern: /跟踪订单 (.+)/i,
      tool: 'get-tracking',
      map: (match) => ({ orderNo: match[1] })
    },
    {
      pattern: /优化产品 (.+) 为 (.+) 平台/i,
      tool: 'optimize-product',
      map: (match) => ({ sku: match[1], platform: match[2] })
    }
  ]
};
