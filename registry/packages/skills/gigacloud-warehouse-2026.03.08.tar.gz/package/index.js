/**
 * 大健云仓 Skill
 * GigaCloud Warehouse Skill for OpenClaw
 * 
 * 跨境电商 B2B 分销平台操作技能
 * 支持产品获取、图片处理、订单推送等功能
 */

const GigaCloudAPI = require('./lib/api');
const ImageProcessor = require('./lib/image');

let api = null;
let imageProcessor = null;

/**
 * 初始化技能
 */
function init(config) {
  api = new GigaCloudAPI({
    domain: config.domain || 'https://api.gigacloudlogistics.com',
    clientId: config.clientId,
    clientSecret: config.clientSecret,
    token: config.token
  });
  
  imageProcessor = new ImageProcessor({
    outputDir: config.outputDir || './output/images'
  });
  
  return { success: true, message: '大健云仓技能已初始化' };
}

/**
 * 获取产品详情（含图片）
 */
async function getProductDetail(skus) {
  if (!api) throw new Error('请先初始化技能');
  return await api.getProductDetail(skus);
}

/**
 * 搜索产品
 */
async function searchProducts(keyword, page = 1, pageSize = 20) {
  if (!api) throw new Error('请先初始化技能');
  return await api.searchProducts(keyword, page, pageSize);
}

/**
 * 获取产品图片
 */
async function getProductImages(sku) {
  if (!api) throw new Error('请先初始化技能');
  return await api.getProductImages(sku);
}

/**
 * 下载产品图片
 */
async function downloadProductImages(sku) {
  if (!api || !imageProcessor) throw new Error('请先初始化技能');
  const product = await api.getProductImages(sku);
  if (product.images && product.images.length > 0) {
    return await imageProcessor.downloadProductImages(product.images, sku);
  }
  return [];
}

/**
 * 获取库存信息
 */
async function getStockInfo(skus) {
  if (!api) throw new Error('请先初始化技能');
  return await api.getStockInfo(skus);
}

/**
 * 创建订单（推送给大健云仓）
 */
async function createOrder(orderData) {
  if (!api) throw new Error('请先初始化技能');
  return await api.createOrder(orderData);
}

/**
 * 获取订单状态
 */
async function getOrderStatus(orderNo) {
  if (!api) throw new Error('请先初始化技能');
  return await api.getOrderStatus(orderNo);
}

/**
 * 获取物流跟踪信息
 */
async function getTrackingInfo(orderNo) {
  if (!api) throw new Error('请先初始化技能');
  return await api.getTrackingInfo(orderNo);
}

/**
 * AI 优化产品信息
 */
async function optimizeProductInfo(sku, targetPlatform) {
  if (!api || !imageProcessor) throw new Error('请先初始化技能');
  const product = await api.getProductDetail(sku);
  if (product && product.data) {
    return imageProcessor.optimizeProductInfo(product.data, targetPlatform);
  }
  return null;
}

/**
 * 生成 AI 处理任务
 */
async function createAITask(sku, modifications) {
  if (!api || !imageProcessor) throw new Error('请先初始化技能');
  const product = await api.getProductDetail(sku);
  if (product && product.data) {
    const task = imageProcessor.prepareAITask(product.data, modifications);
    const taskId = `${sku}_${Date.now()}`;
    const filepath = imageProcessor.saveAITask(task, taskId);
    return { taskId, filepath, task };
  }
  return null;
}

/**
 * 完整工作流：获取产品 -> 下载图片 -> AI 优化 -> 准备发布
 */
async function workflow(sku, options = {}) {
  if (!api || !imageProcessor) throw new Error('请先初始化技能');
  
  const result = {
    sku,
    steps: [],
    data: null
  };
  
  try {
    // Step 1: 获取产品详情
    result.steps.push({ step: 1, name: '获取产品详情', status: 'running' });
    const product = await api.getProductDetail(sku);
    result.data = product;
    result.steps[0].status = 'success';
    
    // Step 2: 下载图片
    if (options.downloadImages !== false && product.data?.images) {
      result.steps.push({ step: 2, name: '下载产品图片', status: 'running' });
      const images = await imageProcessor.downloadProductImages(
        product.data.images, 
        sku
      );
      result.images = images;
      result.steps[1].status = 'success';
    }
    
    // Step 3: AI 优化
    if (options.optimize && options.targetPlatform) {
      result.steps.push({ step: 3, name: 'AI 优化产品信息', status: 'running' });
      const optimized = imageProcessor.optimizeProductInfo(
        product.data, 
        options.targetPlatform
      );
      result.optimized = optimized;
      result.steps[2].status = 'success';
    }
    
    // Step 4: 创建 AI 处理任务
    if (options.aiModifications) {
      result.steps.push({ step: 4, name: '创建 AI 处理任务', status: 'running' });
      const task = await createAITask(sku, options.aiModifications);
      result.aiTask = task;
      result.steps[3].status = 'success';
    }
    
    return result;
  } catch (error) {
    result.error = error.message;
    result.steps.forEach(s => {
      if (s.status === 'running') s.status = 'failed';
    });
    throw error;
  }
}

// 导出所有函数
module.exports = {
  init,
  getProductDetail,
  searchProducts,
  getProductImages,
  downloadProductImages,
  getStockInfo,
  createOrder,
  getOrderStatus,
  getTrackingInfo,
  optimizeProductInfo,
  createAITask,
  workflow
};
